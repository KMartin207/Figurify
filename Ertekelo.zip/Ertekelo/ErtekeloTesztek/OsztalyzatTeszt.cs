using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ertekelo;   // fontos: ez a Console App namespace-e

namespace ErtekeloTesztek
{
    [TestClass]
    public class OsztalyzatTeszt
    {
        [TestMethod]
        public void OtostAd_95Pontra()
        {
            var ertekelo = new ErtekeloSzamitas();

            int eredmeny = ertekelo.OsztalyzatSzamitas(95);

            Assert.AreEqual(5, eredmeny);
        }

        [TestMethod]
        public void HaromastAd_65Pontra()
        {
            var ertekelo = new ErtekeloSzamitas();

            int eredmeny = ertekelo.OsztalyzatSzamitas(65);

            Assert.AreEqual(3, eredmeny);
        }
    }
}