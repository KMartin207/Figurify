﻿using System;

namespace Ertekelo
{
    // Ez az osztály számolja ki az osztályzatot
    public class ErtekeloSzamitas
    {
        public int OsztalyzatSzamitas(int pontszam)
        {
            if (pontszam >= 90)
                return 5;
            else if (pontszam >= 75)
                return 4;
            else if (pontszam >= 60)
                return 3;
            else if (pontszam >= 50)
                return 2;
            else
                return 1;
        }
    }

    public class Osztalyzat
    {
        static void Main(string[] args)
        {
            // Kipróbálás konzolból
            ErtekeloSzamitas ertekelo = new ErtekeloSzamitas();

            Console.Write("Adj meg egy pontszámot: ");
            int pont = int.Parse(Console.ReadLine());

            int jegy = ertekelo.OsztalyzatSzamitas(pont);

            Console.WriteLine("Az osztályzat: " + jegy);
            Console.ReadLine();
        }
    }
}